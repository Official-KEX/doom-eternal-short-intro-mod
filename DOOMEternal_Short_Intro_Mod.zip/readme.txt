########################################
## VERY SPECIFIC - "BUGFIX" INTRO MOD ##
########################################


/////What it does:
After installation, the intro only shows a 3s videoclip from the campaign, instead of the 30 second long (and loud) original intro video.


/////Why:
This will probably only useful for a few people, but:
Using the "Launch Option Parameter" (+com_skipIntroVideo 1) has the potential to, for whatever fucking reason, break your savegame
or make the game not load your profile. Using a shorter intro clip instead of skipping it entirely seems to fix the problem.
At least for me it works. Thats why im sharing it with others.


/////Info:
Im not sure why the "Profile Wipe"-Bug happens sometimes, when using the "Launch Option Parameter" (+com_skipIntroVideo 1).
But if my attempt to "skip" the intro video fails too, you simply have to accept it and watch the original intro.


/////How to install:
1. Prepare the game (OPTIONAL)
SKIP THIS STEP IF YOU ALREADY USED MODINJECTOR ON YOUR INSTALLATION
Otherwise, download, install and run EternalModInjector once -> "https://gamebanana.com/tools/7475"
You dont need to install any mods, just "dry run" it. Make sure to read the instructions there
on how to use/install it.

2. Find your DOOM Eternal Installation folder
- Either browse to it manually
- Or use Steam: Rightclick on DOOM Eternal in Steam > Properties > Installed Files > Browse

3. Extract the "base"-folder into your DOOMEternal folder.
Should look something like this:
X:\SteamLibrary\steamapps\common\DOOMEternal\

4. Verify the files are there
If done correctly, it should look like this:
X:\SteamLibrary\steamapps\common\DOOMEternal\base\video\boot_sequence\Boot_Sequence.bk2

5. Start the game 
And check if the short intro video plays, instead of the long/original video.

6. RIP&TEAR
Until it is done :)


/////Troubleshoot:
Should anything go horribly wrong with your game, after running modinjector or installing this,
or your profile still wont load:

A. Simply "Verify Gamefiles": 
-> In Steam: DOOM Eternal -> Properties -> Installed Files -> "Verify integrity of game files"
Info: This will also wipe any other mods from your installation!

or

B. Rename the files to restore the original "Intro Clip":
- Boot_Sequence.bk2 -> SHORT_Boot_Sequence.bk2
- ORIGINAL_Boot_Sequence.bk2 -> Boot_Sequence.bk2


/////GREETINGS TO:
My Mom, everyone in the DOOM Community, John Romero, id Software, Bethesda and everyone else i forgor.
You are awesome <3

~[KEX]
https://github.com/Official-KEX